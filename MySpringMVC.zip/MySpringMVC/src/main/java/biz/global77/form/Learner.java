package biz.global77.form;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class Learner implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotBlank(message = "Name must not be empty")
	private String empName;

	@NotBlank(message = "Employee ID must not be empty")
	private String empID;
	
	@NotBlank(message = "Age must not be empty")
	private String empAge;
	
	@NotBlank(message = "Email must not be empty")
	private String empEmail;

	public Learner() {
		
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getEmpAge() {
		return empAge;
	}

	public void setEmpAge(String empAge) {
		this.empAge = empAge;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	
	
}

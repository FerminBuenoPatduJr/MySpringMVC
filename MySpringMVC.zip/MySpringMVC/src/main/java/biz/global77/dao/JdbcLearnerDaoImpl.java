package biz.global77.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import biz.global77.form.Learner;

public class JdbcLearnerDaoImpl implements JdbcLearnerDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insert(Learner employee) {

		String sql = "INSERT INTO public.learner (\r\n" + 
		" \"empName\", \"empID\",\"empAge\",\"empEmail\")\r\n"
		+ " VALUES (?,?,?,?)";

		jdbcTemplate.update(sql, new Object[] {employee.getEmpName(),employee.getEmpID(),
				employee.getEmpAge(),employee.getEmpEmail(),});
	}

}
